#!/bin/bash
#getDate(yyyy-MM-dd HH:mm:ss)
#(test)
echo $HOME
§§hi
exit
