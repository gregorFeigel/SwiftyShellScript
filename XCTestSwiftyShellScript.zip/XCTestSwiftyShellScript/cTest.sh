#!/bin/bash
0: - the input format was: yyyy-MM-dd HH:mm:ss
1: - the input format was: yyyy-MM-dd HH:mm:ss
2: - the input format was: yyyy-MM-dd HH:mm:ss
3: - the input format was: yyyy-MM-dd HH:mm:ss
4: - the input format was: yyyy-MM-dd HH:mm:ss
5: - the input format was: yyyy-MM-dd HH:mm:ss
6: - the input format was: yyyy-MM-dd HH:mm:ss
7: - the input format was: yyyy-MM-dd HH:mm:ss
8: - the input format was: yyyy-MM-dd HH:mm:ss
9: - the input format was: yyyy-MM-dd HH:mm:ss
10: - the input format was: yyyy-MM-dd HH:mm:ss

everything worked!
echo $HOME
this is a custom tag
exit
